<?php
$fields_array['ReportParameter'] = array (
	'column_fields' => array(
		"id"
		,"friendly_name"
		,"default_name"
		,"default_value"
		,"description"
		,"range_name"
		,"range_options"
		,"date_entered"
		,"date_modified"
		,"created_by"
		,"modified_user_id"	
	),
        'list_fields' =>  array(
		"id"
		,"friendly_name"
		,"default_name"
		,"default_value"
		,"description"
		,"range_name"
		,"range_options"
		,"date_entered"
		,"date_modified"
		,"created_by"
		,"modified_user_id"	
	),
    	'required_fields' =>  array('name'=>1),
);
?>
