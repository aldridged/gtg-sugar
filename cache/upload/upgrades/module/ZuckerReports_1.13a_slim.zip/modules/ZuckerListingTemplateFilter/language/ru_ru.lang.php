<?php
$mod_strings = return_module_language("ru_ru", "ZuckerReports");
$mod_list_strings = return_mod_list_strings_language("ru_ru", "ZuckerReports");
?>
