<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$dashletStrings['ZuckerReportDisplayDashlet'] = array('LBL_TITLE'            => 'ZuckerReports Dashlet',
                                         'LBL_DESCRIPTION'      => 'Displays live content of a ZuckerReport within a Dashlet ',
                                         'LBL_CONFIGURE_TITLE'  => 'Title',
										 'LBL_NOTITLE' => ' Please select a report',
                                         'LBL_CONFIGURE_RUNNABLE' => 'Runnable Report'
);
?> 
