<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$dashletStrings['ZuckerReportContainerDashlet'] = array('LBL_TITLE'            => 'ZuckerReports Archive',
                                         'LBL_DESCRIPTION'      => 'Zeigt den aktuellen Inhalt einer ZuckerReports Kategorie an',
                                         'LBL_CONFIGURE_TITLE'  => 'Titel',
                                         'LBL_CONFIGURE_CONTAINER' => 'Kategorie',
                                         'LBL_CONFIGURE_COUNT' => 'max. Anzahl von Zeilen',

);
?> 
