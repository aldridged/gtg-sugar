<?php
$fields_array['ReportContainer'] = array (
	'column_fields' => array(
		'id',
		'date_entered',
		'date_modified',
		'modified_user_id',
		'created_by',
		'name',
		'team_id',
		'assigned_user_id',
		'description',
		'parent_id',
		'deleted',
	),
        'list_fields' =>  array(
		'id',
		'date_entered',
		'date_modified',
		'modified_user_id',
		'created_by',
		'name',
		'team_id',
		'assigned_user_id',
		'description',
		'parent_id',
		'deleted',
	),
    	'required_fields' =>  array('name'=>1),
);
?>
