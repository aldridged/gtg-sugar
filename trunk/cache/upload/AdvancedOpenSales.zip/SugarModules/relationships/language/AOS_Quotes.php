<?php
$mod_strings [ "LBL_AOS_QUOTES_PROJECT_FROM_PROJECT_TITLE" ] = "Projects" ;
$mod_strings [ "LBL_AOS_QUOTES_AOS_INVOICES_FROM_AOS_INVOICES_TITLE" ] = "Invoices" ;
