<?php
$mod_strings [ "LBL_AOS_QUOTES_AOS_INVOICES_FROM_AOS_QUOTES_TITLE" ] = "Quotes" ;
