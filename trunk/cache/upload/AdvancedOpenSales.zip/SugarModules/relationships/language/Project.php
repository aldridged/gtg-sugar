<?php
$mod_strings [ "LBL_AOS_QUOTES_PROJECT_FROM_AOS_QUOTES_TITLE" ] = "Quotes" ;
