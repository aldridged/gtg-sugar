<?php
// created: 2010-12-20 02:56:01
$layout_defs["Opportunities"]["subpanel_setup"]["opportunity_aos_quotes"] = array (
  'order' => 100,
  'module' => 'AOS_Quotes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'Quotes',
  'get_subpanel_data' => 'aos_quotes',
);
?>