<?php
// created: 2010-12-20 02:55:45
$dictionary["AOS_Quotes"]["fields"]["aos_quotes_project"] = array (
  'name' => 'aos_quotes_project',
  'type' => 'link',
  'relationship' => 'aos_quotes_project',
  'source' => 'non-db',
);
?>
<?php
// created: 2010-12-20 02:55:45
$dictionary["AOS_Quotes"]["fields"]["aos_quotes_aos_invoices"] = array (
  'name' => 'aos_quotes_aos_invoices',
  'type' => 'link',
  'relationship' => 'aos_quotes_aos_invoices',
  'source' => 'non-db',
);
?>