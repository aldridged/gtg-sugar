<?php
// created: 2010-12-20 02:55:45
$dictionary["Project"]["fields"]["aos_quotes_project"] = array (
  'name' => 'aos_quotes_project',
  'type' => 'link',
  'relationship' => 'aos_quotes_project',
  'source' => 'non-db',
);
?>