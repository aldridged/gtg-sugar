<?php
// created: 2010-12-20 02:55:45
$dictionary["AOS_Invoices"]["fields"]["aos_quotes_aos_invoices"] = array (
  'name' => 'aos_quotes_aos_invoices',
  'type' => 'link',
  'relationship' => 'aos_quotes_aos_invoices',
  'source' => 'non-db',
);
?>