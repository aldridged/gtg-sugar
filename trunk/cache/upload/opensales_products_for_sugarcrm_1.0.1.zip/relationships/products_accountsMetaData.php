<?php

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

$dictionary['products_accounts'] = array (
	'table'  => 'products_accounts',
	'fields' => array (
  array('name'=> 'id',             'type'=> 'char','len'=> '36',  'required'=> true, 'default'=> '')
, array('name'=> 'product_id','type'=> 'char', 'len'=> '36', 'required'=>  true)
, array('name'=> 'account_id',   'type'=> 'char', 'len'=> '36', 'required'=>  true)
, array('name'=> 'date_modified',  'type'=> 'datetime',           'required'=>  true)
, array('name'=> 'deleted',        'type'=> 'bool', 'len'=> '1',  'required'=>  true, 'default'=> '0')
),
 'indices' => array (
  array('name'=>'product_accountpk',       'type'=>'primary',      'fields'=> array('id'))
, array('name'=>'idx_product_id',            'type'=>'index',        'fields'=> array('product_id'))
, array('name'=>'idx_account_id',               'type'=>'index',        'fields'=> array('account_id'))
, array('name'=>'idx_product_account_ids', 'type'=>'alternate_key','fields'=> array('product_id','account_id'))
 ) 
, 'relationships' => array (
   'products_accounts'  => array(
    'lhs_module'        => 'Products',    'lhs_table'=> 'products','lhs_key'=> 'id',
	   'rhs_module'        => 'Accounts', 'rhs_table'=> 'accounts',  'rhs_key'=> 'id',
	   'relationship_type' => 'many-to-many',
	   'join_table'        => 'products_accounts', 'join_key_lhs'=> 'product_id', 'join_key_rhs'=> 'account_id'))
)
?>
