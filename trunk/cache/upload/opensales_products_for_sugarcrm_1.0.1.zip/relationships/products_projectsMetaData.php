<?php

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

$dictionary['products_projects'] = array(
   'table' => 'products_projects', //the table that is created in the database
   'fields' => array (
      array('name' =>'id', 'type' =>'varchar', 'len'=>'36',), // the unique id for the relationship
      array('name' =>'product_id', 'type' =>'varchar', 'len'=>'36'), // the id for the account
      array('name' =>'project_id', 'type' =>'varchar', 'len'=>'36'), // the id for the bug
      array('name' => 'date_modified','type' => 'datetime'), // necessary
      array('name' =>'deleted', 'type' =>'bool', 'len'=>'1', 'required'=>true, 'default'=>'0') // necessary
   ),
   // the indices are necessary for indexing and performance
   'indices' => array (
        array('name' => 'products_projects_pk', 'type' =>'primary', 'fields'=>array('id')),
        array('name' => 'idx_prod_proj_product', 'type' =>'index', 'fields'=>array('product_id')),
        array('name' => 'idx_prod_proj_project', 'type' =>'index', 'fields'=>array('project_id')),
        array('name' => 'products_projects_alt', 'type'=>'alternate_key', 'fields'=>array('product_id','project_id')),
    ),
   'relationships' => array(
     'products_projects' => array(
       'lhs_module'=> 'Products', // the left hand module - should match $beanList index
       'lhs_table'=> 'products', // the left hand table name
       'lhs_key' => 'id', // the key to use from the left table
       'rhs_module'=> 'Project', // the right hand module - should match $beanList index
       'rhs_table'=> 'project', // the right hand table name
       'rhs_key' => 'id', // the key to use from the right table
       'relationship_type'=>'many-to-many', // relationship type
       'join_table'=> 'products_projects', // join table - table used to join items
       'join_key_lhs'=>'product_id', // left table key - should exist in table field definitions above
       'join_key_rhs'=>'project_id' // right table key - should exist in table field definitions above
     )
   )
 )
?>