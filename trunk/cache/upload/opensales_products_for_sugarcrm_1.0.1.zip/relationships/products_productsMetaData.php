<?php

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

$dictionary['products_products'] = array(
  'table'  => 'products_products', 
  'fields' => array(
    array('name' => 'id', 'type' => 'char' ,'len' => '36', 'required' => true, 'default' => ''), 
    array('name' => 'predecessor_product_id', 'type' => 'char', 'len' => '36', 'required' => true), 
    array('name' => 'product_id', 'type' => 'char', 'len' => '36', 'required' => true), 
    array('name' => 'date_modified', 'type' => 'datetime', 'required' => true), 
    array('name' => 'deleted', 'type' => 'bool', 'len' => '1', 'required' => true, 'default'=> '0')
  ),
  'indices' => array(
    array('name' => 'prod_rel_pk', 'type' => 'primary', 'fields' => array('id')), 
    array('name' => 'idx_predecessor_product_id', 'type' => 'index', 'fields' => array('predecessor_product_id')), 
    array('name' => 'idx_product_id', 'type' => 'index', 'fields' => array('product_id')), 
    array('name' => 'idx_predecessor_product_ids', 'type' => 'alternate_key','fields' => array('predecessor_product_id','product_id'))
  )
)

?>