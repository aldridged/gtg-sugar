OpenSales for SugarCRM features an advanced, robust set of business extensions
for sales and support management and inventory control including quotes and
products and contract modules.
