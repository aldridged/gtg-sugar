<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

   require_once('data/SugarBean.php');
   require_once('include/utils.php');

// SHOULD INCLUDE SELECTIVELY
   require_once('modules/Contacts/Contact.php');
   require_once('modules/Tasks/Task.php');
   require_once('modules/Notes/Note.php');
   require_once('modules/Calls/Call.php');
   require_once('modules/Cases/Case.php');
   require_once('modules/Accounts/Account.php');

// PRODUCTS IS USED TO STORE PRODUCTS INFORMATION.
class Product extends SugarBean {
   var $field_name_map = array();
// STORED FIELDS
  	var $id;
  	var $date_entered;
  	var $date_modified;
  	var $modified_user_id;
  	var $assigned_user_id;
/*  
//BUILDER:START Pro only 
  	var $team_id;
//BUILDER:END Pro only 
*/  
  	var $description;
  	var $name;
  
//BUILDER:START of table columns 
//BUILDER: included table columns
  var $availability;
  var $category;
  var $contact;
  var $cost;
  var $date_available;
  var $manufacturer;
  var $mfr_part_num;
  var $price;
  var $supplier;
  var $type;
  var $vendor_part_num;
 //BUILDER:END of table columns 

//BUILDER:START of related information
var $predecessor_product_id; 
//BUILDER:END of related information 
/*  
//BUILDER:START Pro only 
  	var $team_name;
  	var $system_id;
//BUILDER:END Pro only 
*/

// BEGIN Additional fields being added to Product
// END Additional fields being added to Product
	
	  var $module_dir        = 'Products';
	  var $table_name        = "products";
	  var $object_name       = "Product";
   
//BUILDER:START of table names 
//BUILDER:END of table names 


// THIS IS USED TO RETRIEVE RELATED FIELDS FROM FORM POSTS.
  	var $additional_column_fields = Array(
  	     'assigned_user_name', 
  	     'assigned_user_id', 
  	     'modified_user_id',
  	     'created_by',
//BUILDER:START of additional column fields
         'predecessor_product_id' 
//BUILDER:END of additional column fields 
  	    );
  
  	var $relationship_fields = Array(
//BUILDER:START of relationship fields 
         'predecessor_product_id' => 'related_products'
//BUILDER:END of relationship fields 
  					);

  	function Product() {
  		parent::SugarBean();
  		$this->setupCustomFields('Products');
  		foreach ($this->field_defs as $field)
    {
     $this->field_name_map[$field['name']] = $field;
    }
/*
//BUILDER:START Pro only 
  		$this->team_id = 1; // make the item globally accessible
//BUILDER:END Pro only 
*/
  	}
  
  	var $new_schema = true;
  
  	function get_summary_text(){
  		return "$this->name";
  	}
  
  	function create_list_query($order_by, $where, $show_deleted = 0){
// Fill in the assigned_user_name
//	$this->assigned_user_name = get_assigned_user_name($this->assigned_user_id);
	 	 $custom_join = $this->custom_fields->getJOIN();
    $query   = "SELECT ";
	 	 $query  .= "
                     products.*
                    ,users.user_name as assigned_user_name";
/*
//BUILDER:START Pro only 
    $query  .= ", teams.name AS team_name";
//BUILDER:END Pro only 
*/
    if($custom_join){
	 	  $query .= $custom_join['select'];
    }
    $query  .= " FROM products 
           								LEFT JOIN users
                          ON products.assigned_user_id=users.id";
    
	 	 // WE NEED TO CONFIRM THAT THE USER IS A MEMBER OF THE TEAM OF THE ITEM.
/*
//BUILDER:START Pro only 
	 	 $this->add_team_security_where_clause($query);
//BUILDER:START Pro only 
*/
//	 	 $query .= "				LEFT JOIN releases ON products.found_in_release=releases.id
//           								LEFT JOIN users
//                          ON products.assigned_user_id=users.id";

/*
//BUILDER:START Pro only 
    $query .= "    LEFT JOIN teams ON products.team_id=teams.id";
//BUILDER:START Pro only 
*/
    $query .= "  ";
	 	 if($custom_join){
	 	  $query .= $custom_join['join'];
    }
    $where_auto = '1=1';
	 	 if($show_deleted == 0){
    	$where_auto = " $this->table_name.deleted=0 ";
	 	 }else if($show_deleted == 1){
	 	 	$where_auto = " $this->table_name.deleted=1 ";	
	 	 }
    
	 	 if($where != "")
	 	 	$query .= "where $where AND ".$where_auto;
	 	 else
	 	 	$query .= "where ".$where_auto;
	 	 if(substr_count($order_by, '.') > 0){
	 	 	$query .= " ORDER BY $order_by";
	 	 }
	 	 else if($order_by != "")
	 	 	$query .= " ORDER BY $order_by";
	 	 else
	 	 	$query .= " ORDER BY products.name";
	 	 
	 	 return $query;
	  }

   function create_export_query($order_by, $where){
  		$custom_join = $this->custom_fields->getJOIN();
    $query       = "SELECT
                    products.*,
                    users.user_name assigned_user_name";
    if($custom_join){
  			$query .=  $custom_join['select'];
  		}
    $query .= " FROM products ";
  
//  WE NEED TO CONFIRM THAT THE USER IS A MEMBER OF THE TEAM OF THE ITEM.
/*
//BUILDER:START Pro only 
  		$this->add_team_security_where_clause($query);
//BUILDER:START Pro only 
*/
  		$query .= "				LEFT JOIN users
                          ON products.assigned_user_id=users.id";
    if($custom_join){
  			$query .=  $custom_join['join'];
  		}
    $query  .= "";
    $where_auto = "  products.deleted=0
                  ";
  
    if($where != "")
     $query .= " where $where AND ".$where_auto;
    else
     $query .= " where ".$where_auto;
  
    if($order_by != "")
     $query .= " ORDER BY $order_by";
    else
     $query .= " ORDER BY products.name";
  
    return $query;
   }
  	
  	function fill_in_additional_list_fields(){
  	}
  
  	function fill_in_additional_detail_fields(){
// FILL IN THE ASSIGNED_USER_NAME
  		$this->assigned_user_name = get_assigned_user_name($this->assigned_user_id);
/*
//BUILDER:START Pro only 
  		$this->assigned_name      = get_assigned_team_name($this->team_id);
    $this->team_name          = $this->assigned_name;        
//BUILDER:END Pro only 
*/
  		$this->created_by_name    = get_assigned_user_name($this->created_by);
  		$this->modified_by_name   = get_assigned_user_name($this->modified_user_id);
  		
  		//$this->cost = format_number($this->cost);
  		//$this->price = format_number($this->price);
  	}
  	
  	function get_list_view_data(){
  		global $current_language;
  		$the_array        = parent::get_list_view_data();
  		$app_list_strings = return_app_list_strings_language($current_language);
  		$mod_strings      = return_module_language($current_language, 'Products');
    	    
  // THE NEW LISTVIEW CODE ONLY FETCHES COLUMNS THAT WE'RE DISPLAYING AND NOT ALL
  // THE COLUMNS SO WE NEED THESE CHECKS. 
  	   $the_array['NAME'] = (($this->name == "") ? "<em>blank</em>" : $this->name);
  	   $the_array['ENCODED_NAME']   = $this->name;
  	   
  	   $the_array['COST'] = currency_format_number($this->cost);
  	   $the_array['PRICE'] = currency_format_number($this->price);
  	   $the_array['COST_COPY'] = format_number($this->cost);
  	   $the_array['PRICE_COPY'] = format_number($this->price);
/*
//BUILDER:START Pro only 
//    NUMBER FORMAT: NUM + SYSTEM_ID
     	$the_array['PRODUCTS_NUMBER'] = format_number_display($this->PRODUCT_number,$this->system_id);
//BUILDER:START Pro only 
*/      			
     	return  $the_array;
  	}
  
  	/**
  		BUILDS A GENERIC SEARCH BASED ON THE QUERY STRING USING OR.
  		DO NOT INCLUDE ANY $THIS-> BECAUSE THIS IS CALLED ON WITHOUT HAVING THE CLASS INSTANTIATED.
  	*/
  	function build_generic_where_clause ($the_query_string) {
   	$where_clauses    = Array();
   	$the_query_string = PearDatabase::quote(from_html($the_query_string));
   	array_push($where_clauses, "products.name like '$the_query_string%'");
   
   	$the_where = "";
   	foreach($where_clauses as $clause){
   		if($the_where != "") $the_where .= " or ";
   		$the_where .= $clause;
   	}
   	return $the_where;
  	}
  
  	function set_notification_body($xtpl, $PRODUCT){
  		global $mod_strings, $app_list_strings;
  
  		$xtpl->assign("NAME",        $PRODUCT->name);
  		$xtpl->assign("PRODUCTS_DESCRIPTION",    $PRODUCT->description);
  		return $xtpl;
  	}
  	
  	function bean_implements($interface){
  		switch($interface){
  			case 'ACL':return true;
  		}
  		return false;
  	}
  	
  	function save($check_notify = FALSE){
/*
//BUILDER:START Pro only 
  		if (!isset($this->system_id) || empty($this->system_id)){
  			require_once("modules/Administration/Administration.php");
  			$admin     = new Administration();
  			$admin->retrieveSettings();
  			$system_id = $admin->settings['system_system_id'];
  			if (!isset($system_id)){
  				$system_id = 1;
  			}
  			$this->system_id = $system_id;
  		}
//BUILDER:END Pro only 
*/
  		return parent::save($check_notify);
  	}

}
?>
