<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

/*******************************************************************************
 * Subpanel Layout definition for Products
 *******************************************************************************/


$subpanel_layout = array(
    'top_buttons' => array(
        array('widget_class' => 'SubPanelTopCreateButton'),
        array('widget_class' => 'SubPanelTopSelectButton', 'popup_module' => 'Products'),
    ),

    'where' => '',

    'list_fields' => array(
        'name'=>array(
         'vname'        => 'LBL_LIST_SUBJECT',
         'widget_class' => 'SubPanelDetailViewLink',
         'width'        => '35%',
        ),
        'category'=>array(
         'vname'        => 'LBL_CATEGORY',
         'width'        => '15%',
        ),
        'type'=>array(
         'vname'        => 'LBL_TYPE',
         'width'        => '15%',
        ),
        'availability'=>array(
         'vname'        => 'LBL_AVAILABILITY',
         'width'        => '10%',
        ),
        'price'=>array(
         'vname'        => 'LBL_PRICE',
         'width'        => '15%',
        ),
//        'assigned_user_name' => array (
//         'name'         => 'assigned_user_name',
//         'vname'        => 'LBL_LIST_ASSIGNED_TO_NAME',
//        ),
        'edit_button'=>array(
         'widget_class' => 'SubPanelEditButton',
         'module'       => 'Products',
         'width'        => '5%',
        ),
    ),
);

?>
