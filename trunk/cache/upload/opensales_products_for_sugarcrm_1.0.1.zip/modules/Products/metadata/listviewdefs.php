<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

/*******************************************************************************
 * Fields to appear in ListView
 *******************************************************************************/
$listViewDefs['Products'] = array (
  'NAME' => 
  array (
    'width' => '20',
    'label' => 'LBL_LIST_NAME',
    'default' => true,
    'link' => true,
  ),
  /*
//BUILDER:START Pro only 
	'TEAM_NAME' => array(
		'width'   => '9', 
		'label'   => 'LBL_LIST_TEAM',
  'default' => true),
//BUILDER:END Pro only 
*/
  'TYPE' => 
  array (
    'width' => 10,
    'label' => 'LBL_LIST_TYPE',
    'default' => true,
  ),
  'CATEGORY' => 
  array (
    'width' => 10,
    'label' => 'LBL_LIST_CATEGORY',
    'default' => true,
  ),
  'AVAILABILITY' => 
  array (
    'width' => 10,
    'label' => 'LBL_LIST_AVAILABILITY',
    'default' => true,
  ),
  'QUANTITY' => 
  array (
    'width' => 10,
    'label' => 'LBL_LIST_QUANTITY',
    'default' => true,
  ),
  'COST' => 
  array (
    'width' => 10,
    'label' => 'LBL_LIST_COST',
    'default' => true,
  ),
  'PRICE' => 
  array (
    'width' => 10,
    'label' => 'LBL_LIST_PRICE',
    'default' => true,
  ),
  //'ASSIGNED_USER_NAME' => 
  //array (
  //  'width' => '2',
  //  'label' => 'LBL_LIST_ASSIGNED_USER',
  //  'default' => true,
  //),
  'MANUFACTURER' => 
  array (
    'width' => 10,
    'label' => 'LBL_LIST_MANUFACTURER',
    'default' => false,
  ),
  'SUPPLIER' => 
  array (
    'width' => 10,
    'label' => 'LBL_LIST_SUPPLIER',
    'default' => false,
  ),
  'MFR_PART_NUM' => 
  array (
    'width' => 10,
    'label' => 'LBL_LIST_MFR_PART_NUM',
    'default' => false,
  ),
  'DATE_AVAILABLE' => 
  array (
    'width' => 10,
    'label' => 'LBL_LIST_DATE_AVAILABLE',
    'default' => false,
  ),
  'CONTACT' => 
  array (
    'width' => 10,
    'label' => 'LBL_LIST_CONTACT',
    'default' => false,
  ),
);
?>
