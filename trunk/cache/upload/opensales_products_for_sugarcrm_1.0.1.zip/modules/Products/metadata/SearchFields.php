<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

$searchFields['Products'] = 
	array (
		'name' => array( 'query_type'=>'default'),
		'manufacturer'=> array('query_type'=>'default'),
		'mfr_part_num'=> array('query_type'=>'default'),
		'vendor_part_num'=> array('query_type'=>'default'),
		'category'=> array('query_type'=>'default', 'operator'=>'=', 'options' => 'product_category_options', 'template_var' => 'OPTIONS_CATEGORY'),
		'type'=> array('query_type'=>'default', 'operator'=>'=', 'options' => 'product_type_options', 'template_var' => 'OPTIONS_TYPE'),
		'current_user_only'=> array('query_type'=>'default','db_field'=>array('assigned_user_id'),'my_items'=>true),
		'assigned_user_id'=> array('query_type'=>'default'),
	);
?>
