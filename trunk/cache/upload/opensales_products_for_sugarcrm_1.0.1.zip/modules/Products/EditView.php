<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

/*********************************************************************************
 * EDITVIEW FOR SIMPLE MODULE TEMPLATE
 ********************************************************************************/

// INCLUDE SUPPPORT MODULES
   require_once('XTemplate/xtpl.php');
   require_once('data/Tracker.php');

// INCLUDE MODULE OBJECT AND FORMS
   require_once('modules/Products/Product.php');
   require_once('modules/Products/Forms.php');
   require_once('modules/Releases/Release.php');
   
   global $app_strings;
   global $app_list_strings;
   global $mod_strings;
   global $mod_strings;
   global $current_user;
   global $sugar_version, $sugar_config;
   
// INSTANTIATES THE MODULE CLASSES  
   $focus       = new Product();
   $seedRelease = new Release();
   
// IF PROCESSING AN EXISTING RECORD, RETRIEVE IT  
   if(isset($_REQUEST['record'])) {
    $focus->retrieve($_REQUEST['record']);
   }
   if(isset($_REQUEST['isDuplicate']) && $_REQUEST['isDuplicate'] == 'true') {
   	$focus->id             = "";
   	$focus->PRODUCT_number = "";
   }
   
//needed when creating a new opportunity with a default account value passed in
$prefillArray = array('contact_name' => 'contact',
                      'contact_id' => 'contact_id');
foreach($prefillArray as $requestKey => $focusVar) {
    if (isset($_REQUEST[$requestKey]) && is_null($focus->$focusVar)) {
        $focus->$focusVar = urldecode($_REQUEST[$requestKey]);
    }
}
   
// BUILD MODULE TITLE LINE  
   echo "\n<p>\n";
   echo get_module_title($mod_strings['LBL_MODULE_ID'], $mod_strings['LBL_MODULE_NAME'].": ".$focus->name, true);
   echo "\n</p>\n";

   global $theme;
   $theme_path = "themes/".$theme."/";
   $image_path = $theme_path."images/";
   require_once ($theme_path.'layout_utils.php');
   
   $GLOBALS['log']->info("Product detail view");
   
// ASSIGN XTEMPLATE
   $xtpl = new XTemplate ('modules/Products/EditView.html');

// FILL XTEMPLATE MODULE & APPLICATION LANGUAGE STRINGS
   $xtpl->assign("MOD", $mod_strings);
   $xtpl->assign("APP", $app_strings);
   
   if (isset($_REQUEST['return_module'])) $xtpl->assign("RETURN_MODULE", $_REQUEST['return_module']);
   if (isset($_REQUEST['return_action'])) $xtpl->assign("RETURN_ACTION", $_REQUEST['return_action']);
   if (isset($_REQUEST['return_id']))     $xtpl->assign("RETURN_ID",     $_REQUEST['return_id']);
   
   if (empty($_REQUEST['return_id'])) {
   	$xtpl->assign("RETURN_ACTION", 'index');
   }
   
///////////////////////////////////////
// SETUP POPUPS START
   $json               = getJSONobj();
// Accounts Popup
	$popup_request_data = array(
		'call_back_function' => 'set_return',
		'form_name' => 'EditView',
		'field_to_name_array' => array(
			'id' => 'manufacturer_id',
			'name' => 'manufacturer',
			),
		);
	
	$xtpl->assign('encoded_manufacturer_popup_request_data', $json->encode($popup_request_data));
	
// Contacts Popup
	$popup_request_data = array(
		'call_back_function' => 'set_return',
		'form_name' => 'EditView',
		'field_to_name_array' => array(
			'id' => 'contact_id',
			'name' => 'contact',
			),
		);
	
	$xtpl->assign('encoded_contacts_popup_request_data', $json->encode($popup_request_data));
	
// Users Popup
   $popup_request_data = array(
   	'call_back_function'  => 'set_return',
   	'form_name'           => 'EditView',
   	'field_to_name_array' => array(
   		'id'        => 'assigned_user_id',
   		'user_name' => 'assigned_user_name',
   		),
   	);
   $xtpl->assign('encoded_users_popup_request_data', $json->encode($popup_request_data));
//
////////////////////////////////////////////////////////////////////////////////
   
/*
//BUILDER:START Pro only 
////////////////////////////////////////////////////////////////////////////////
// Team Popup
   $popup_request_data = array(
   	'call_back_function'  => 'set_return',
   	'form_name'           => 'EditView',
   	'field_to_name_array' => array(
   		'id'   => 'team_id',
   		'name' => 'team_name',
   		),
   	);
   $xtpl->assign('encoded_team_popup_request_data', $json->encode($popup_request_data));
//
////////////////////////////////////////////////////////////////////////////////
//BUILDER:END Pro only 
*/
   
// ACCOUNT_ID WILL BE SET WHEN USER CHOOSES TO CREATE A NEW PRODUCTS FROM ACCOUNT DETAIL VIEW.
   if (isset($_REQUEST['account_id'])) $xtpl->assign("ACCOUNT_ID", $_REQUEST['account_id']);
   if (isset($_REQUEST['contact_id'])) $xtpl->assign("CONTACT_ID", $_REQUEST['contact_id']);
   
// SET THE CASE_ID, IF SET.
// WITH NEW CONCEPT OF SUBPANELS IT, 
// WHEN THE SUBPANEL IS DISPLAYED IT PULLS FROM THE CLASS NAME WHICH IN THE SITUATION OF CASES IS ACASE SO THE FORM IS GENERATED
// WITH ACASE_ID INSTEAD OF CASE_ID, SO I HAVE DONE THE MAPPING HERE
   if (isset($_REQUEST['acase_id']))    $xtpl->assign("CASE_ID",$_REQUEST['acase_id']);
   else if(isset($_REQUEST['case_id'])) $xtpl->assign("CASE_ID",$_REQUEST['case_id']);

////////////////////////////////////////////////////////////////////////////////
// QUICK SEARCH SETUP
   require_once('include/QuickSearchDefaults.php');
   $qsd = new QuickSearchDefaults();
   $sqs_objects = array(
   	'assigned_user_name' => $qsd->getQSUser(),
/*
//BUILDER:START Pro only 
   	'team_name'          => $qsd->getQSTeam()
//BUILDER:END Pro only 
*/
   );
   $quicksearch_js  = $qsd->getQSScripts();
   $quicksearch_js .= '<script type="text/javascript" language="javascript">sqs_objects = ' . $json->encode($sqs_objects) . '</script>';
// QUICK SEARCH SETUP
////////////////////////////////////////////////////////////////////////////////
   
////////////////////////////////////////////////////////////////////////////////
// ASSIGN GLOBAL VARIABLES
   $xtpl->assign("THEME",             $theme);
   $xtpl->assign("IMAGE_PATH",        $image_path);$xtpl->assign("PRINT_URL", "index.php?".$GLOBALS['request_string']);
   $xtpl->assign("JAVASCRIPT",        get_set_focus_js().get_validate_record_js(). $quicksearch_js);
// ASSIGN GLOBAL VARIABLES
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// ASSIGN MODULE DEFAULT VARIABLES
   $xtpl->assign("ID",                $focus->id);
   if (isset($focus->name)) 
        $xtpl->assign("NAME",         $focus->name);
   else $xtpl->assign("NAME",         "");
   $xtpl->assign("DATE_ENTERED",      $focus->date_entered);
   $xtpl->assign("DATE_MODIFIED",     $focus->date_modified);
   $xtpl->assign("CREATED_BY",        $focus->created_by_name);
   $xtpl->assign("MODIFIED_BY",       $focus->modified_by_name);

   if (empty($focus->assigned_user_id) && empty($focus->id))  $focus->assigned_user_id   = $current_user->id;
   if (empty($focus->assigned_name)    && empty($focus->id))  $focus->assigned_user_name = $current_user->user_name;
   $xtpl->assign("ASSIGNED_USER_OPTIONS",    get_select_options_with_id(get_user_array(TRUE, "Active", $focus->assigned_user_id), $focus->assigned_user_id));
   $xtpl->assign("ASSIGNED_USER_NAME",       $focus->assigned_user_name);
   $xtpl->assign("ASSIGNED_USER_ID",         $focus->assigned_user_id );
   
// ASSIGN MODULE SPECIFIC VARIABLES
   $xtpl->assign("DESCRIPTION",       $focus->description);
   
// ASSIGN MODULE DROPDOWNS WITH DEFAULT KEY
   
// ASSIGN MODULE VARIABLES AFFECTED BY DUPLICATE ACTION   
   if(!isset($_REQUEST['isDuplicate'])) {
    $focus->id = "";
   }


// ASSIGN MODULE DROPDOWNS WITHOUT DEFAULT KEY
//BUILDER: included fields
 $xtpl->assign('CALENDAR_DATEFORMAT', $timedate->get_cal_date_format()); $xtpl->assign('USER_DATEFORMAT', $timedate->get_user_date_format());  $xtpl->assign('AVAILABILITY',  $focus->availability);
if (empty($focus->availability)) {
$xtpl->assign("OPTIONS_AVAILABILITY", get_select_options_with_id($app_list_strings['product_availability_options'], $app_list_strings['product_availability_options_default_key']));
}else{
$xtpl->assign("OPTIONS_AVAILABILITY", get_select_options_with_id($app_list_strings['product_availability_options'], $focus->availability));
}
  $xtpl->assign('CATEGORY',  $focus->category);
if (empty($focus->category)) {
$xtpl->assign("OPTIONS_CATEGORY", get_select_options_with_id($app_list_strings['product_category_options'], $app_list_strings['product_category_options_default_key']));
}else{
$xtpl->assign("OPTIONS_CATEGORY", get_select_options_with_id($app_list_strings['product_category_options'], $focus->category));
}
  $xtpl->assign('CONTACT',  $focus->contact);
  $xtpl->assign('CONTACT_ID',  $focus->contact_id);
  $xtpl->assign('COST',  format_number($focus->cost));
  $xtpl->assign('DATE_AVAILABLE',  $focus->date_available);
  $xtpl->assign('MANUFACTURER',  $focus->manufacturer);
  $xtpl->assign('MANUFACTURER_ID',  $focus->manufacturer_id);
  $xtpl->assign('MFR_PART_NUM',  $focus->mfr_part_num);
  $xtpl->assign('PRICE',  format_number($focus->price));
  $xtpl->assign('TYPE',  $focus->type);
if (empty($focus->type)) {
$xtpl->assign("OPTIONS_TYPE", get_select_options_with_id($app_list_strings['product_type_options'], $app_list_strings['product_type_options_default_key']));
}else{
$xtpl->assign("OPTIONS_TYPE", get_select_options_with_id($app_list_strings['product_type_options'], $focus->type));
}
  $xtpl->assign('VENDOR_PART_NUM',  $focus->vendor_part_num);
  $xtpl->assign('URL',  $focus->url);
  $xtpl->assign('QUANTITY',  $focus->quantity);
  $xtpl->assign('WEIGHT',  $focus->weight);
//BUILDER:END of xtpl

require_once('modules/Currencies/Currency.php');
$currency  = new Currency();
if(isset($focus->currency_id) && !empty($focus->currency_id))
{
	$currency->retrieve($focus->currency_id);
	if( $currency->deleted != 1){
		$xtpl->assign("CURRENCY", $currency->iso4217 .' '.$currency->symbol );
	}else $xtpl->assign("CURRENCY", $currency->getDefaultISO4217() .' '.$currency->getDefaultCurrencySymbol() );
}else{

	$xtpl->assign("CURRENCY", $currency->getDefaultISO4217() .' '.$currency->getDefaultCurrencySymbol() );

}

// ADD CUSTOM FIELDS
   require_once('modules/DynamicFields/templates/Files/EditView.php');

////////////////////////////////////////////////////////////////////////////////
// USER ASSIGNMENT
   global $current_user;
   if(is_admin($current_user) && $_REQUEST['module'] != 'DynamicLayout' && !empty($_SESSION['editinplace'])){
   	$record = '';
// USER ASSIGNMENT
////////////////////////////////////////////////////////////////////////////////

   	if(!empty($_REQUEST['record'])){
   		$record = 	$_REQUEST['record'];
   	}
   	$xtpl->assign("ADMIN_EDIT","<a href='index.php?action=index&module=DynamicLayout&from_action=".$_REQUEST['action'] ."&from_module=".$_REQUEST['module'] ."&record=".$record. "'>".get_image($image_path."EditLayout","border='0' alt='Edit Layout' align='bottom'")."</a>");
   }

/*
//BUILDER:START Pro only 
   if (empty($focus->id) && !isset($_REQUEST['isDuplicate'])) {
   	$xtpl->assign("TEAM_OPTIONS", get_select_options_with_id(get_team_array(), $current_user->default_team));	
   	$xtpl->assign("TEAM_NAME",    $current_user->default_team_name);
   	$xtpl->assign("TEAM_ID",      $current_user->default_team);
   }else{
   	$xtpl->assign("TEAM_OPTIONS", get_select_options_with_id(get_team_array(), $focus->team_id));
   	$xtpl->assign("TEAM_NAME",    $focus->assigned_name);
   	$xtpl->assign("TEAM_ID",      $focus->team_id);
   }
   $xtpl->parse("main.pro");
//BUILDER:END Pro only 
*/   
   
   $xtpl->parse("main");
   $xtpl->out("main");
   require_once('include/javascript/javascript.php');
   $javascript = new javascript();
   $javascript->setFormName('EditView');
   $javascript->setSugarBean($focus);
   $javascript->addAllFields('');

//BUILDER:START Pro only 
//   $javascript->addFieldGeneric(              'team_name',          'varchar', $app_strings['LBL_TEAM'] ,'true');
//   $javascript->addToValidateBinaryDependency('team_name',          'alpha',   $app_strings['ERR_SQS_NO_MATCH_FIELD'] . $app_strings['LBL_TEAM'],        'false', '', 'team_id');
//BUILDER:END Pro only 

   $javascript->addToValidateBinaryDependency('assigned_user_name', 'alpha',   $app_strings['ERR_SQS_NO_MATCH_FIELD'] . $app_strings['LBL_ASSIGNED_TO'], 'false', '', 'assigned_user_id');
   
   echo $javascript->getScript();
   
   require_once('modules/SavedSearch/SavedSearch.php');
   $savedSearch        = new SavedSearch();
   $json               = getJSONobj();
   $savedSearchSelects = $json->encode(array($GLOBALS['app_strings']['LBL_SAVED_SEARCH_SHORTCUT'] . '<br>' . $savedSearch->getSelect('Products')));
   $str = "<script>
   YAHOO.util.Event.addListener(window, 'load', SUGAR.util.fillShortcuts, $savedSearchSelects);
   </script>";
   echo $str;
?>
