<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

require_once('XTemplate/xtpl.php');
require_once("data/Tracker.php");
require_once("include/ListView/ListView.php");

global $app_strings;
global $current_language;
$current_module_strings = return_module_language($current_language, 'Products');
$header_text            = '';
global $currentModule;
global $theme;
global $focus;
global $action;

$theme_path="themes/".$theme."/";
$image_path=$theme_path."images/";
require_once($theme_path.'layout_utils.php');

///////////////////////////////////////
/// SETUP PARENT POPUP
    $popup_request_data = array(
    	'call_back_function'  => 'set_return_and_save',
    	'form_name'           => 'DetailView',
    	'field_to_name_array' => array(
    		'id' => 'PRODUCT_id',
    		),
    	);
    $json = getJSONobj();
    $encoded_popup_request_data = $json->encode($popup_request_data);
///
///////////////////////////////////////

// FOCUS_LIST IS THE MEANS OF PASSING DATA TO A SUBPANELVIEW.
global $focus_list;

$button   = "<form  action='index.php' method='post' name='form' id='form'>\n";
$button  .= "<input type='hidden' name='module'       value='Products'>\n";

if ($currentModule == 'Accounts') {
 $button .= "<input type='hidden' name='account_id'   value='$focus->id'>\n";
 $button .= "<input type='hidden' name='account_name' value='$focus->name'>\n";

}elseif ($currentModule == 'Contacts') {
 $button .= "<input type='hidden' name='account_id'   value='$focus->account_id'>\n";
 $button .= "<input type='hidden' name='account_name' value='$focus->account_name'>\n";
 $button .= "<input type='hidden' name='contact_id'   value='$focus->id'>\n";

}elseif ($currentModule == 'Cases') {
 $button .= "<input type='hidden' name='case_id' value='$focus->id'>\n";
}  

$button  .= "<input type='hidden' name='return_module' value='".$currentModule."'>\n";
$button  .= "<input type='hidden' name='return_action' value='".$action."'>\n";
$button  .= "<input type='hidden' name='return_id'     value='".$focus->id."'>\n";
$button  .= "<input type='hidden' name='action'>\n";
$button  .= "<input title='".$app_strings['LBL_NEW_BUTTON_TITLE']   
                            ."' accessKey='".$app_strings['LBL_NEW_BUTTON_KEY']   
                            ."' class='button' onclick=\"this.form.action.value='EditView'\" type='submit' name='New' value='  "
                            .$app_strings['LBL_NEW_BUTTON_LABEL']."  '>\n";
$button  .= "<input title='".$app_strings['LBL_SELECT_BUTTON_TITLE']."' accessKey='"
                            .$app_strings['LBL_SELECT_BUTTON_KEY']."' type='button' class='button' value='  "
                            .$app_strings['LBL_SELECT_BUTTON_LABEL']
	."  ' name='button' onclick='open_popup(\"Products\", 600, 400, \"\", false, true, {$encoded_popup_request_data});'>\n";
$button  .= "</form>\n";

$ListView = new ListView();
$ListView->initNewXTemplate( 'modules/Products/SubPanelView.html',$current_module_strings);
$ListView->xTemplateAssign("RETURN_URL",         "&return_module=".$currentModule."&return_action=DetailView&return_id={$_REQUEST['record']}");
$ListView->xTemplateAssign("EDIT_INLINE_PNG",    get_image($image_path.'edit_inline',  'align="absmiddle" alt="'.$app_strings['LNK_EDIT']  .'" border="0"'));
$ListView->xTemplateAssign("DELETE_INLINE_PNG",  get_image($image_path.'delete_inline','align="absmiddle" alt="'.$app_strings['LNK_REMOVE'].'" border="0"'));

if(is_admin($current_user) && $_REQUEST['module'] != 'DynamicLayout' && !empty($_SESSION['editinplace'])){	
	$header_text = "&nbsp;<a href='index.php?action=index&module=DynamicLayout&from_action=SubPanelView&from_module=Products&record="
	               .$_REQUEST['record']."'>"
	               .get_image($image_path."EditLayout","border='0' alt='Edit Layout' align='bottom'")
	               ."</a>";
}
$ListView->setHeaderTitle($current_module_strings['LBL_MODULE_NAME'] . $header_text );
$ListView->setHeaderText($button);
$ListView->processListView($focus_list, "main", "PRODUCTS");
?>
