<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

$mod_strings = array (
  'LBL_MODULE_NAME'                 => 'Products',
  'LBL_MODULE_TITLE'                => 'Products: Home',
  'LBL_MODULE_ID'                   => 'Products',  
  'LBL_SEARCH_FORM_TITLE'           => 'Product Search',
  'LBL_LIST_FORM_TITLE'             => 'Product List',
  'LBL_NEW_FORM_TITLE'              => 'New Product',
  'LBL_CONTACT_PRODUCTS_TITLE'  	=> 'Contact-Product:',
  'LBL_SUBJECT'                     => 'Product Name:',
  'LBL_PRODUCTS'                	=> 'Product:',
  'LBL_PRODUCTS_NUMBER'         	=> 'Product Number:',
  'LBL_NUMBER'                      => 'Number:',
  'LBL_STATUS'                      => 'Status:',
  'LBL_PRIORITY'                    => 'Priority:',
  'LBL_NAME'                        => 'Product Name:',
  'LBL_DESCRIPTION'                 => 'Description:',
  'LBL_CONTACT_NAME'                => 'Contact Name:',
  'LBL_PRODUCTS_SUBJECT'        	=> 'Product Subject:',
  'LBL_CONTACT_ROLE'                => 'Role:',
  'LBL_LIST_NUMBER'                 => 'Num.',
  'LBL_LIST_NAME'                   => 'Name',
  'LBL_LIST_SUBJECT'                => 'Product',
  'LBL_LIST_STATUS'                 => 'Status',
  'LBL_LIST_PRIORITY'               => 'Priority',
  'LBL_LIST_RELEASE'                => 'Release',
  'LBL_LIST_RESOLUTION'             => 'Resolution',
  'LBL_LIST_LAST_MODIFIED'          => 'Last Modified',
  'LBL_INVITEE'                     => 'Contacts',
  'LBL_TYPE'                        => 'Type:',
  'LBL_LIST_TYPE'                   => 'Type',
  'LBL_RESOLUTION'                  => 'Resolution:',
  'LBL_RELEASE'                     => 'Release:',
  'LNK_NEW_PRODUCTS'               	=> 'New Product',
  'LNK_PRODUCTS_LIST'              	=> 'Products',
  'NTC_REMOVE_INVITEE'              => 'Are you sure you want to remove this contact from the PRODUCT?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Are you sure you want to remove this PRODUCT from this account?',
  'ERR_DELETE_RECORD'               => 'A record number must be specified to delete the PRODUCT.',
  'LBL_LIST_MY_PRODUCTS'       		=> 'My Assigned Products',
  'LBL_FOUND_IN_RELEASE'            => 'Found in Release:',
  'LBL_FIXED_IN_RELEASE'            => 'Fixed in Release:',
  'LBL_LIST_FIXED_IN_RELEASE'       => 'Fixed in Release',  
  'LBL_WORK_LOG'                    => 'Work Log:',
  'LBL_SOURCE'                      => 'Source:',
  'LBL_PRODUCT_CATEGORY'            => 'Category:',
  'LBL_CREATED_BY'                  => 'Created by:',

  'LBL_ASSIGNED_USER_ID'            => 'Assigned To:',

  'LBL_DATE_CREATED'                => 'Create Date:',
  'LBL_MODIFIED_BY'                 => 'Last Modified by:',
  'LBL_DATE_LAST_MODIFIED'          => 'Modify Date:',
  'LBL_LIST_EMAIL_ADDRESS'          => 'Email Address',
  'LBL_LIST_CONTACT_NAME'           => 'Contact Name',
  'LBL_LIST_ACCOUNT_NAME'           => 'Account Name',
  'LBL_LIST_PHONE'                  => 'Phone',
  'NTC_DELETE_CONFIRMATION'         => 'Are you sure you want to remove this contact from this PRODUCT?',
  'LBL_DEFAULT_SUBPANEL_TITLE'      => 'Products',
  'LBL_ACTIVITIES_SUBPANEL_TITLE'   => 'Activities',
  'LBL_HISTORY_SUBPANEL_TITLE'      => 'History',
  'LBL_CONTACTS_SUBPANEL_TITLE'     => 'Contacts',
  'LBL_ACCOUNTS_SUBPANEL_TITLE'     => 'Accounts',
  'LBL_CASES_SUBPANEL_TITLE'        => 'Cases',
  'LBL_PRODUCTS_SUBPANEL_TITLE'     => 'Related Products',
  'LBL_SYSTEM_ID'                   => 'System ID',
  'LBL_LIST_ASSIGNED_TO_NAME'       => 'Assigned User',

  'LBL_DATE_ENTERED'                => 'Date Created:',
  'LBL_DATE_MODIFIED'               => 'Last Modified',
  'LBL_ASSIGNED_TO'                 => 'Assigned to:',
  'LBL_CREATED'                     => 'Created by:',
  'LBL_MODIFIED'                    => 'Modified by:',

  'LNK_PRODUCTS_REPORTS'        	=> 'Product Reports',

//FOR SubPanels
  'LBL_PRODUCTS'               		=> 'Products',

 //BUILDER:START menu labels 
 'LNK_NEW_PRODUCTS' => 'Create Products',
 'LNK_LIST_PRODUCTS' => 'Products',
 //BUILDER:END menu labels 

 //BUILDER:START subpanels labels 
 //BUILDER:END subpanels labels 

 //BUILDER:START of labels 
 'CATEGORY_C' =>  'category',
 'TYPE_C' =>  'type',
 'AVAILABILITY_C' =>  'availability',
 'PRICE_C' =>  'price',
//BUILDER: included labels
 'LBL_AVAILABILITY' => 'Availability:',
 'LBL_CATEGORY' => 'Category Name:',
 'LBL_CONTACT' => 'Contact Name:',
 'LBL_COST' => 'Cost:',
 'LBL_DATE_AVAILABLE' => 'Date Available:',
 'LBL_MANUFACTURER' => 'Manufacturer:',
 'LBL_MANUFACTURER_ID' => 'Manufacturer ID:',
 'LBL_MFR_PART_NUM' => 'Mfr Part Number:',
 'LBL_PRICE' => 'List Price:',
 'LBL_TYPE' => 'Product Type:',
 'LBL_VENDOR_PART_NUM' => 'Vendor Part Number:',
 'LBL_URL' => 'Product Url:',
 'LBL_QUANTITY' => 'Quantity in Stock:',
 'LBL_WEIGHT' => 'Weight:',
//BUILDER:END of labels
 'LBL_LIST_PRODUCT' => 'Product',

 'LBL_LIST_AVAILABILITY' => 'Availability',
 'LBL_LIST_CATEGORY' => 'Category',
 'LBL_LIST_CONTACT' => 'Contact',
 'LBL_LIST_COST' => 'Cost',
 'LBL_LIST_DATE_AVAILABLE' => 'Date Available',
 'LBL_LIST_MANUFACTURER' => 'Manufacturer',
 'LBL_LIST_MFR_PART_NUM' => 'Mfr Part Number',
 'LBL_LIST_PRICE' => 'List',
 'LBL_LIST_TYPE' => 'Type',
 'LBL_LIST_VENDOR_PART_NUM' => 'Vendor Part Number',
 'LBL_LIST_URL' => 'Product Url',
 'LBL_LIST_QUANTITY' => 'Qty',
 'LBL_LIST_WEIGHT' => 'Weight',
);
?>
