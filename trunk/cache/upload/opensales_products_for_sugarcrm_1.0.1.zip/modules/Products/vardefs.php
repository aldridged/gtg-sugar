<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

$dictionary['Product'] = array(
'table'    => 'products',
'audited'           =>  true, 
'comment'           => 'Products are information about products and services',
'duplicate_merge'   =>  true,
'unified_search'    =>  true,
'fields' => array (
  'id' =>   array (
    'name'              => 'id',
    'vname'             => 'LBL_ID',
    'type'              => 'id',
    'required'          =>  true,
    'reportable'        =>  false,
    'comment'           => 'Unique identifier'
  ),

  'date_entered' =>   array (
    'name'              => 'date_entered',
    'vname'             => 'LBL_DATE_ENTERED',
    'type'              => 'datetime',
    'required'          =>  true,
    'comment'           => 'Date record created'
  ),
  'date_modified' =>   array (
    'name'              => 'date_modified',
    'vname'             => 'LBL_DATE_MODIFIED',
    'type'              => 'datetime',
    'required'          =>  true,
    'comment'           => 'Date record last modified'
  ),
  'modified_user_id' =>   array (
    'name'              => 'modified_user_id',
    'rname'             => 'user_name',
    'id_name'           => 'modified_user_id',
    'vname'             => 'LBL_MODIFIED',
    'type'              => 'assigned_user_name',
    'table'             => 'modified_user_id_users',
    'isnull'            => 'false',
    'dbType'            => 'varchar',
    'len'               =>  36,
    'reportable'        =>  true,
    'massupdate'        =>  false,
    'comment'           => 'User who last modified record'
  ),
  'assigned_user_id' =>   array (
    'name'              => 'assigned_user_id',
    'rname'             => 'user_name',
    'id_name'           => 'assigned_user_id',
    'vname'             => 'LBL_ASSIGNED_TO',
    'type'              => 'relate',
    'table'             => 'users',
    'isnull'            => 'true',
    'dbType'            => 'varchar',
    'reportable'        =>  true,
    'len'               =>  36,
    'audited'           =>  true,
    'comment'           => 'User assigned to record',
    'module'            => 'Users',
    'duplicate_merge'   => 'disabled'           
    
  ),
  'assigned_user_name' =>   array (
    'name'              => 'assigned_user_name',
    'vname'             => 'LBL_ASSIGNED_TO',
    'type'              => 'varchar',
    'reportable'        =>  false,
    'source'            => 'nondb',
    'table'             => 'users',
    'duplicate_merge'   => 'disabled'
  ),
  
// START Subpanels  
  'tasks' => 
  array (
  	'name' => 'tasks',
    'type' => 'link',
    'relationship' => 'products_tasks',
    'source'=>'non-db',
    'module'=>'Tasks',
    'bean_name'=>'Task',
		'vname'=>'LBL_TASKS',
  ),
  'notes' => 
  array (
  	'name' => 'notes',
    'type' => 'link',
    'relationship' => 'products_notes',
    'source'=>'non-db',
    'module'=>'Notes',
    'bean_name'=>'Note',
		'vname'=>'LBL_NOTES',
  ),
  'meetings' => 
  array (
  	'name' => 'meetings',
    'type' => 'link',
    'relationship' => 'products_meetings',
    'source'=>'non-db',
    'module'=>'Meetings',
    'bean_name'=>'Meeting',
		'vname'=>'LBL_MEETINGS',
  ),
  'calls' => 
  array (
  	'name' => 'calls',
    'type' => 'link',
    'relationship' => 'products_calls',
    'source'=>'non-db',
    'module'=>'Calls',
    'bean_name'=>'Call',
		'vname'=>'LBL_CALLS',
  ),
// END Subpanels

/*
//BUILDER:START Pro only 
  'team_id' =>   array (
    'name'              => 'team_id',
    'vname'             => 'LBL_TEAM_ID',
    'reportable'        =>  false,
    'dbtype'            => 'id',
    'type'              => 'team_list',
    'audited'           =>  true,
    'comment'           => 'The team ID for the Product'
  ),
    'team_name' =>   array (
    'name'              => 'team_name',
    'rname'             => 'name',
    'id_name'           => 'team_id',
    'vname'             => 'LBL_TEAM',
    'type'              => 'relate',
    'link'              => 'team_link',
    'table'             => 'teams',
    'isnull'            => 'true',
    'module'            => 'Teams',
    'massupdate'        =>  false,
    'dbType'            => 'varchar',
    'len'               =>  36,
    'source'            => 'non-db',
  ),
//BUILDER:START Pro only 
*/
 'deleted' =>   array (
    'name'              => 'deleted',
    'vname'             => 'LBL_CREATED_BY',
    'type'              => 'bool',
    'required'          =>  true,
    'reportable'        =>  false,
    'comment'           => 'Record deletion indicator'
  ),
 'name' =>   array (
    'name'              => 'name',
    'vname'             => 'LBL_NAME',
    'type'              => 'name',
    'dbType'            => 'varchar',
    'len'               =>  255,
    'audited'           =>  true,
    'unified_search'    =>  true,
    'comment'           => 'The short description of the PRODUCT',
    'merge_filter'      => 'selected',
  ),
  'description' =>   array (
    'name'              => 'description',
    'vname'             => 'LBL_DESCRIPTION',
    'type'              => 'text',
    'comment'           => 'A full description of the PRODUCT'
  ),
  'created_by' =>   array (
    'name'              => 'created_by',
    'rname'             => 'user_name',
    'id_name'           => 'created_by',
    'vname'             => 'LBL_CREATED',
    'type'              => 'assigned_user_name',
    'table'             => 'created_by_users',
    'isnull'            => 'false',
    'dbType'            => 'varchar',
    'len'               =>  36,
    'comment'           => 'User that created the record'
  ),
  'created_by_link' =>  array (
    'name'              => 'created_by_link',
    'type'              => 'link',
    'relationship'      => 'products_created_by',
    'vname'             => 'LBL_CREATED_BY_USER',
    'link_type'         => 'one',
    'module'            => 'Users',
    'bean_name'         => 'User',
    'source'            => 'non-db',
  ),
  'modified_user_link' =>  array (
    'name'              => 'modified_user_link',
    'type'              => 'link',
    'relationship'      => 'products_modified_user',
    'vname'             => 'LBL_MODIFIED_BY_USER',
    'link_type'         => 'one',
    'module'            => 'Users',
    'bean_name'         => 'User',
    'source'            => 'non-db',
  ),
  'assigned_user_link' =>  array (
    'name'              => 'assigned_user_link',
    'type'              => 'link',
    'relationship'      => 'products_assigned_user',
    'vname'             => 'LBL_ASSIGNED_TO_USER',
    'link_type'         => 'one',
    'module'            => 'Users',
    'bean_name'         => 'User',
    'source'            => 'non-db',
    'duplicate_merge'   => 'enabled',
    'rname'             => 'user_name',
    'id_name'           => 'assigned_user_id',
    'table'             => 'users',     
  ),
  

//BUILDER:START of fields
 /*'product_products' => 
  array (
    'name' => 'product_products',
    'type' => 'link',
    'relationship' => 'product_products',
    'module'=>'Products',
    'bean_name'=>'Product',
    'source'=>'non-db',
        'vname'=>'LBL_PRODUCTS',
  ),*/ 
//BUILDER: included fields

'availability' => array(
 'name'       => 'availability',
 'vname'      => 'LBL_AVAILABILITY',
 'type'       => 'enum',
 'audited'    =>  false,
 'massupdate' =>  true,
 'options'    => 'product_availability_options',
),

'category' => array(
 'name'       => 'category',
 'vname'      => 'LBL_CATEGORY',
 'type'       => 'enum',
 'audited'    =>  false,
 'massupdate' =>  true,
 'options'    => 'product_category_options',
),

'contact' => array(
 'name'       => 'contact',
 'vname'      => 'LBL_CONTACT',
 'type'       => 'varchar',
 'len'        =>  50,
 'audited'    =>  false,
 'massupdate' =>  false,
 'options'    => '',
),

'contact_id' =>   array (
  'name'              => 'contact_id',
  'vname'             => 'LBL_CONTACT_ID',
  'type'              => 'id',
  'reportable'        =>  false,
  'comment'           => 'Contact unique identifier'
 ),

'cost' => array(
 'name'       => 'cost',
 'vname'      => 'LBL_COST',
 'dbType'	  => 'decimal',
 'type'		  => 'currency',
 'len'		  => '16,2',
 'audited'    =>  false,
 'options'    => '',
),

'date_available' => array(
 'name'       => 'date_available',
 'vname'      => 'LBL_DATE_AVAILABLE',
 'type'       => 'date',
 'audited'    =>  true,
 'massupdate' =>  true,
 'options'    => '',
),

'manufacturer' => array(
 'name'       => 'manufacturer',
 'vname'      => 'LBL_MANUFACTURER',
 'type'       => 'varchar',
 'len'        =>  50,
 'audited'    =>  false,
 'massupdate' =>  true,
 'options'    => '',
),

'manufacturer_id' =>   array (
 'name'              => 'manufacturer_id',
 'vname'             => 'LBL_MANUFACTURER_ID',
 'type'              => 'id',
 'reportable'        =>  false,
 'comment'           => 'Manufacturer unique identifier'
),

'mfr_part_num' => array(
 'name'       => 'mfr_part_num',
 'vname'      => 'LBL_MFR_PART_NUM',
 'type'       => 'varchar',
 'len'        =>  50,
 'audited'    =>  false,
 'options'    => '',
),

'price' => array(
 'name'       => 'price',
 'vname'      => 'LBL_PRICE',
 'dbType'	  => 'decimal',
 'type'		  => 'currency',
 'len'		  => '16,2',
 'audited'    =>  false,
 'options'    => '',
),

'type' => array(
 'name'       => 'type',
 'vname'      => 'LBL_TYPE',
 'type'       => 'enum',
 'audited'    =>  false,
 'massupdate' =>  true,
 'options'    => 'product_type_options',
),

'vendor_part_num' => array(
 'name'       => 'vendor_part_num',
 'vname'      => 'LBL_VENDOR_PART_NUM',
 'type'       => 'varchar',
 'len'        =>  50,
 'audited'    =>  false,
 'options'    => '',
),

'url' => array(
 'name'       => 'url',
 'vname'      => 'LBL_URL',
 'type'       => 'varchar',
 'len'        =>  50,
 'audited'    =>  false,
 'options'    => '',
),

'quantity' => array(
 'name'       => 'quantity',
 'vname'      => 'LBL_QUANTITY',
 'type'       => 'varchar',
 'len'        =>  50,
 'audited'    =>  false,
 'options'    => '',
),

'weight' => array(
 'name'       => 'weight',
 'vname'      => 'LBL_WEIGHT',
 'type'       => 'varchar',
 'len'        =>  50,
 'audited'    =>  false,
 'options'    => '',
),
//BUILDER:END of fields 
),

'indices' => array (
 array('name' =>'productspk',       'type' =>'primary', 'fields'=>array('id')),
 array('name' =>'idx_PRODUCT_name', 'type' =>'index',   'fields'=>array('name'))
//BUILDER:START of indices 
//BUILDER:END of indices 
)

, 'relationships' => array (
	'products_calls' => array('lhs_module'=> 'Products', 'lhs_table'=> 'products', 'lhs_key' => 'id',
							  'rhs_module'=> 'Calls', 'rhs_table'=> 'calls', 'rhs_key' => 'parent_id',	
							  'relationship_type'=>'one-to-many', 'relationship_role_column'=>'parent_type',
							  'relationship_role_column_value'=>'Products')
	,'products_meetings' => array('lhs_module'=> 'Products', 'lhs_table'=> 'products', 'lhs_key' => 'id',
							  'rhs_module'=> 'Meetings', 'rhs_table'=> 'meetings', 'rhs_key' => 'parent_id',	
							  'relationship_type'=>'one-to-many', 'relationship_role_column'=>'parent_type',
							  'relationship_role_column_value'=>'Products')
	,'products_tasks' => array('lhs_module'=> 'Products', 'lhs_table'=> 'products', 'lhs_key' => 'id',
							  'rhs_module'=> 'Tasks', 'rhs_table'=> 'tasks', 'rhs_key' => 'parent_id',	
							  'relationship_type'=>'one-to-many', 'relationship_role_column'=>'parent_type',
							  'relationship_role_column_value'=>'Products')	
	,'products_notes' => array('lhs_module'=> 'Products', 'lhs_table'=> 'products', 'lhs_key' => 'id',
							  'rhs_module'=> 'Notes', 'rhs_table'=> 'notes', 'rhs_key' => 'parent_id',	
							  'relationship_type'=>'one-to-many', 'relationship_role_column'=>'parent_type',
							  'relationship_role_column_value'=>'Products')
    ,'products_assigned_user' => array(
       'lhs_module'=> 'Users',         'lhs_table'=> 'users',         'lhs_key' => 'id',
       'rhs_module'=> 'Products', 'rhs_table'=> 'products', 'rhs_key' => 'assigned_user_id',
       'relationship_type'=>'one-to-many')
  
    ,'products_modified_user' => array(
       'lhs_module'=> 'Users',         'lhs_table'=> 'users',         'lhs_key' => 'id',
       'rhs_module'=> 'Products', 'rhs_table'=> 'products', 'rhs_key' => 'modified_user_id',
       'relationship_type'=>'one-to-many')
  
    ,'products_created_by' => array(
       'lhs_module'=> 'Users',         'lhs_table'=> 'users',         'lhs_key' => 'id',
       'rhs_module'=> 'Products', 'rhs_table'=> 'products', 'rhs_key' => 'created_by',
       'relationship_type'=>'one-to-many')

//BUILDER:START of relationships  
	/*,'products_products' => array(
      'lhs_module'        => 'Products', 'lhs_table' => 'products', 'lhs_key' => 'id', 
      'rhs_module'        => 'Products', 'rhs_table' => 'products', 'rhs_key' => 'id', 
      'relationship_type' => 'many-to-many', 
      'join_table'        => 'product_products', 'join_key_lhs' => 'product_id', 'join_key_rhs' => 'predecessor_product_id'
    )*/
//BUILDER:END of relationships 
),         
//This enables optimistic locking for Saves From EditView
    'optimistic_locking'=>true,                   
);
?>
