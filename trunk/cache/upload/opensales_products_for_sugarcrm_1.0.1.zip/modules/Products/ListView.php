<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

require_once ('XTemplate/xtpl.php');
require_once ("data/Tracker.php");
require_once ('modules/Products/Product.php');
require_once ('themes/'.$theme.'/layout_utils.php');
require_once ('log4php/LoggerManager.php');
require_once('include/ListView/ListViewSmarty.php');
require_once ("modules/Releases/Release.php");
require_once('modules/Currencies/Currency.php');
   if(file_exists('custom/modules/Products/metadata/listviewdefs.php')){
   	require_once('custom/modules/Products/metadata/listviewdefs.php');	
   }else{
   	require_once('modules/Products/metadata/listviewdefs.php');
   }
   require_once('modules/SavedSearch/SavedSearch.php');
   require_once('include/SearchForm/SearchForm.php');
   
   
   $header_text = '';
   
   global $app_strings, $mod_strings;
   global $app_list_strings;
   global $current_language;
   $current_module_strings = return_module_language($current_language, 'Products');
   
   global $urlPrefix;
   global $currentModule;
   
   global $theme;
   global $current_user;
// FOCUS_LIST IS THE MEANS OF PASSING DATA TO A LISTVIEW.
   global $focus_list;
   
// SETUP QUICKSEARCH
   require_once('include/QuickSearchDefaults.php');
   $qsd = new QuickSearchDefaults();
   
   // CLEAR THE DISPLAY COLUMNS BACK TO DEFAULT WHEN CLEAR QUERY IS CALLED
   if(!empty($_REQUEST['clear_query']) && $_REQUEST['clear_query'] == 'true')  
       $current_user->setPreference('ListViewDisplayColumns', array(), 0, $currentModule);
   
   $savedDisplayColumns = $current_user->getPreference('ListViewDisplayColumns', $currentModule); // GET USER DEFINED DISPLAY COLUMNS
   
   $json = getJSONobj();
      
   $seedProduct = new Product();                                 // SEED BEAN
   $searchForm       = new SearchForm('Products', $seedProduct); // NEW SEARCHFORM INSTANCE
   
// SETUP LISTVIEW SMARTY
   $lv = new ListViewSmarty();
   
   $displayColumns = array();
// CHECK $_REQUEST IF NEW DISPLAY COLUMNS FROM POST
   if (!empty($_REQUEST['displayColumns'])) {
    foreach (explode('|', $_REQUEST['displayColumns']) as $num => $col) {
     if (!empty($listViewDefs['Products'][$col])) 
      $displayColumns[$col] = $listViewDefs['Products'][$col];
    }    
   }elseif(!empty($savedDisplayColumns)) { // USE USER DEFINED DISPLAY COLUMNS FROM PREFERENCES 
       $displayColumns = $savedDisplayColumns;
   }else { // USE COLUMNS DEFINED IN LISTVIEWDEFS FOR DEFAULT DISPLAY COLUMNS
    foreach($listViewDefs['Products'] as $col => $params) {
     if(!empty($params['default']) && $params['default'])
      $displayColumns[$col] = $params;
    }
   } 
   $params = array('massupdate' => true); // SETUP LISTVIEWSMARTY PARAMS
   if(!empty($_REQUEST['orderBy'])) {     // ORDER BY COMING FROM $_REQUEST
    $params['orderBy'] = $_REQUEST['orderBy'];
    $params['overrideOrder'] = true;
    if(!empty($_REQUEST['sortOrder'])) $params['sortOrder'] = $_REQUEST['sortOrder'];
   }
   
   $lv->displayColumns = $displayColumns;
   
   if(!empty($_REQUEST['search_form_only']) && $_REQUEST['search_form_only']) { // HANDLE AJAX REQUESTS FOR SEARCH FORMS ONLY
       switch($_REQUEST['search_form_view']) {
           case 'basic_search':
               $searchForm->setup();
               $searchForm->displayBasic(false);
               break;
           case 'advanced_search':
               $searchForm->setup();
               $searchForm->displayAdvanced(false);
               break;
           case 'saved_views':
               echo $searchForm->displaySavedViews($listViewDefs, $lv, false);
               break;
       }
       return;
   }
   
// USE THE STORED QUERY IF THERE IS ONE
   if (!isset($where)) $where = "";
   require_once('modules/MySettings/StoreQuery.php');
   $storeQuery = new StoreQuery();

   if(!isset($_REQUEST['query'])){
    $storeQuery->loadQuery($currentModule);
    $storeQuery->populateRequest();
   }else{
    $storeQuery->saveFromGet($currentModule);   
   }
   if(isset($_REQUEST['query'])){
    // WE HAVE A QUERY
    // FIRST SAVE COLUMNS 
    $current_user->setPreference('ListViewDisplayColumns', $displayColumns, 0, $currentModule); 
    $searchForm->populateFromRequest();                                  // GATHERS SEARCH FIELD INPUTS FROM $_REQUEST
    $where_clauses = $searchForm->generateSearchWhere(true, "Products"); // BUILDS THE WHERE CLAUSE FROM SEARCH FIELD INPUTS
   
    if (count($where_clauses) > 0 )$where = implode(' and ', $where_clauses);
    $GLOBALS['log']->info("Here is the where clause for the list view: $where");
   }
   
   // START DISPLAY
   // WHICH TAB OF SEARCH FORM TO DISPLAY
   if(!isset($_REQUEST['search_form']) || $_REQUEST['search_form'] != 'false') {
    $searchForm->setup();
    if(isset($_REQUEST['searchFormTab'])      && $_REQUEST['searchFormTab'] == 'advanced_search') {
     $searchForm->displayAdvanced();
    }elseif(isset($_REQUEST['searchFormTab']) && $_REQUEST['searchFormTab'] == 'saved_views'){
     $searchForm->displaySavedViews($listViewDefs, $lv);
    }else {
     $searchForm->displayBasic();
    }
   }
   
   echo $qsd->GetQSScripts();
   
   $lv->setup($seedProduct, 'include/ListView/ListViewGeneric.tpl', $where, $params);
   
   $savedSearchName = empty($_REQUEST['saved_search_select_name']) ? '' : (' - ' . $_REQUEST['saved_search_select_name']);
   echo get_form_header($current_module_strings['LBL_LIST_FORM_TITLE'] . $savedSearchName, '', false);
   echo $lv->display();
   
   $savedSearch = new SavedSearch();
   $json        = getJSONobj();
   // FILLS IN SAVED VIEWS SELECT BOX ON SHORTCUT MENU
   $savedSearchSelects = $json->encode(array($GLOBALS['app_strings']['LBL_SAVED_SEARCH_SHORTCUT'] . '<br>' . $savedSearch->getSelect('Products')));
   $str                = "<script>
   YAHOO.util.Event.addListener(window, 'load', SUGAR.util.fillShortcuts, $savedSearchSelects);
   </script>";
   echo $str;
?>

