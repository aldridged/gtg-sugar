<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

/*********************************************************************************
 * BUILD QUICK CREATE (FROM LEFT MENU)
 ********************************************************************************/

  require_once("modules/Releases/Release.php");

/*******************************************************************************
 * CREATE JAVASCRIPT TO VALIDATE THE DATA ENTERED INTO A RECORD.
 *******************************************************************************/
  function get_validate_record_js () {
  
  }

/*******************************************************************************
 * CREATE HTML FORM TO ENTER A NEW RECORD WITH THE MINIMUM NECESSARY FIELDS.
 *******************************************************************************/
  function get_new_record_form () {
  if(!ACLController::checkAccess('Products', 'edit', true)){
  	return '';
  }
  global $mod_strings;
  global $app_strings;
  global $app_list_strings;
  global $mod_strings;
  global $theme;
  global $current_user;
  
  $lbl_subject           = $mod_strings['LBL_SUBJECT'];
  $lbl_availability = $mod_strings['LBL_AVAILABILITY'];
  $lbl_cost = $mod_strings['LBL_COST'];
  $lbl_price = $mod_strings['LBL_PRICE'];
  $lbl_required_symbol   = $app_strings['LBL_REQUIRED_SYMBOL'];
  $lbl_save_button_title = $app_strings['LBL_SAVE_BUTTON_TITLE'];
  $lbl_save_button_key   = $app_strings['LBL_SAVE_BUTTON_KEY'];
  $lbl_save_button_label = $app_strings['LBL_SAVE_BUTTON_LABEL'];
  $user_id               = $current_user->id;
  
  $options_availability = get_select_options_with_id($app_list_strings['product_availability_options'], $app_list_strings['product_availability_options_default_key']);

/*
//BUILDER:START Pro only 
$team_id               = $current_user->default_team;
//BUILDER:END Pro only 
*/

$the_form         = get_left_form_header($mod_strings['LBL_NEW_FORM_TITLE']);
$the_form         .= <<<EOQ

		<form name="ProductSave" onSubmit="return check_form('ProductSave')" method="POST" action="index.php">
			<input type="hidden" name="module" value="Products">
			<input type="hidden" name="record" value="">
 		    <input type="hidden" name="assigned_user_id" value='${user_id}'>
			<input type="hidden" name="action" value="Save">

<!--
//BUILDER:START Pro only 
			<input type="hidden" name="team_id" value='${team_id}'>
//BUILDER:END Pro only 
-->
		${lbl_subject}&nbsp;<span class="required">${lbl_required_symbol}</span><br>
		<p><input name='name' type="text" size='20' maxlength="50"value=""><br></p>
		
		${lbl_availability}&nbsp;<br>
		<p><select name="availability">${options_availability}</select><br></p>
		
		${lbl_cost}&nbsp;<span class="required">${lbl_required_symbol}</span><br>
		<p><input name='cost' type="text" size='16' maxlength="16"value=""><br></p>
		
		${lbl_price}&nbsp;<span class="required">${lbl_required_symbol}</span><br>
		<p><input name='price' type="text" size='16' maxlength="16"value=""><br></p>
		
<p>
 <input title="${lbl_save_button_title}" accessKey="${lbl_save_button_key}" class="button" type="submit" name="button" value="  ${lbl_save_button_label}  " >
</p>

		</form>
EOQ;
require_once('include/javascript/javascript.php');
require_once('modules/Products/Product.php');
$javascript = new javascript();
$javascript->setFormName('ProductSave');
$javascript->setSugarBean(new Product());
$javascript->addRequiredFields('');
$the_form  .=$javascript->getScript();
$the_form  .= get_left_form_footer();

return $the_form;
}

?>
