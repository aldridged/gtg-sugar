<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

   require_once('XTemplate/xtpl.php');
   require_once('data/Tracker.php');
   require_once('modules/Products/Product.php');
   require_once('modules/Products/Forms.php');
   require_once('include/DetailView/DetailView.php');
   
   //require_once('modules/Currencies/Currency.php');
   
   global $mod_strings;
   global $app_strings;
   global $app_list_strings;
   global $gridline;
   
   $focus      = new Product();
   
   $detailView = new DetailView();
   $offset     = 0;

// ONLY LOAD A RECORD IF A RECORD ID IS GIVEN;
// A RECORD ID IS NOT GIVEN WHEN VIEWING IN LAYOUT EDITOR
   if (isset($_REQUEST['offset']) or isset($_REQUEST['record'])) {
   	$result = $detailView->processSugarBean("PRODUCTS", $focus, $offset);
   	if($result == null) {
   	 sugar_die($app_strings['ERROR_NO_RECORD']);
   	}
   	$focus = $result;
   }else{
   	header("Location: index.php?module=Products&action=index");
   }

   if(isset($_REQUEST['isDuplicate']) && $_REQUEST['isDuplicate'] == 'true') {
   	$focus->id = "";
   }
   echo "\n<p>\n";
   echo get_module_title($mod_strings['LBL_MODULE_ID'], $mod_strings['LBL_MODULE_NAME'].": ".$focus->name, true);
   echo "\n</p>\n";
   global $theme;
   $theme_path = "themes/".$theme."/";
   $image_path = $theme_path."images/";
   require_once($theme_path.'layout_utils.php');
   
   $GLOBALS['log']->info("Product detail view");
   
   $xtpl=new XTemplate ('modules/Products/DetailView.html');
   $xtpl->assign("MOD",          $mod_strings);
   $xtpl->assign("APP",          $app_strings);
   $xtpl->assign("THEME",        $theme);
   $xtpl->assign("GRIDLINE",     ($gridline) ? $gridline : 0);
   $xtpl->assign("IMAGE_PATH",   $image_path);
   $xtpl->assign("PRINT_URL",   "index.php?".$GLOBALS['request_string']);
   $xtpl->assign("ID",           $focus->id);
   $xtpl->assign("ASSIGNED_TO",  $focus->assigned_user_name);
   $xtpl->assign("NAME",         $focus->name);
   $xtpl->assign("DATE_ENTERED", $focus->date_entered);
   $xtpl->assign("DATE_MODIFIED", $focus->date_modified);
   $xtpl->assign("DESCRIPTION",   nl2br(url2html($focus->description)));
//BUILDER: included fields
  $xtpl->assign('AVAILABILITY',  $focus->availability);
  $xtpl->assign('AVAILABILITY',  $app_list_strings['product_availability_options'][$focus->availability]);
  $xtpl->assign('CATEGORY',  $focus->category);
  $xtpl->assign('CATEGORY',  $app_list_strings['product_category_options'][$focus->category]);
  $xtpl->assign('CONTACT',  $focus->contact);
  $xtpl->assign('CONTACT_ID',  $focus->contact_id);
  $xtpl->assign('COST',  currency_format_number($focus->cost));
  $xtpl->assign('DATE_AVAILABLE',  $focus->date_available);
  $xtpl->assign('MANUFACTURER',  $focus->manufacturer);
  $xtpl->assign('MANUFACTURER_ID',  $focus->manufacturer_id);
  $xtpl->assign('MFR_PART_NUM',  $focus->mfr_part_num);
  $xtpl->assign('PRICE',  currency_format_number($focus->price));
  $xtpl->assign('TYPE',  $focus->type);
  $xtpl->assign('TYPE',  $app_list_strings['product_type_options'][$focus->type]);
  $xtpl->assign('VENDOR_PART_NUM',  $focus->vendor_part_num);
  $xtpl->assign('URL',  $focus->url);
  $xtpl->assign('QUANTITY',  $focus->quantity);
  $xtpl->assign('WEIGHT',  $focus->weight);
//BUILDER:END of xtpl


// BUILDER:START Pro only
// $xtpl->assign("PRODUCTS_NUMBER", format_number_display($focus->PRODUCT_number,$focus->system_id));
// BUILDER:END Pro only

   
   global $current_user;
   
   if(is_admin($current_user) && $_REQUEST['module'] != 'DynamicLayout' && !empty($_SESSION['editinplace'])){
   	$xtpl->assign("ADMIN_EDIT","<a href='index.php?action=index&module=DynamicLayout&from_action=".$_REQUEST['action'] ."&from_module=".$_REQUEST['module'] ."&record=".$_REQUEST['record']. "'>".get_image($image_path."EditLayout","border='0' alt='Edit Layout' align='bottom'")."</a>");
   }

   $xtpl->assign("CREATED_BY",    $focus->created_by_name);
   $xtpl->assign("MODIFIED_BY",   $focus->modified_by_name);
   
   $detailView->processListNavigation($xtpl, "PRODUCTS", $offset, $focus->is_AuditEnabled());

// ADDING CUSTOM FIELDS:
   require_once('modules/DynamicFields/templates/Files/DetailView.php');
   
/*
// PRO only
   $xtpl->assign("TEAM", $focus->assigned_name);
   $xtpl->parse("main.pro");
// PRO only
*/
   if(!empty($focus->id)) {
    $merge_button = <<<EOQ
<input title="{$app_strings['LBL_DUP_MERGE']}" accessKey="M" class="button" onclick="this.form.return_module.value='Products'; this.form.return_action.value='DetailView';this.form.return_id.value='{$focus->id}'; this.form.action.value='Step1'; this.form.module.value='MergeRecords';" type="submit" name="Merge" value=" {$app_strings['LBL_DUP_MERGE']} "/>
EOQ;
    $xtpl->assign("FIND_DUPES_MERGE_BUTTON", $merge_button);
   }
   
   $xtpl->parse("main");
   $xtpl->out("main");
   
   $sub_xtpl     = $xtpl;
   $old_contents = ob_get_contents();
   ob_end_clean();
   ob_start();
   echo $old_contents;
   
   require_once('include/SubPanel/SubPanelTiles.php');
   $subpanel = new SubPanelTiles($focus, 'Products');
   echo $subpanel->display();
   
   require_once('modules/SavedSearch/SavedSearch.php');
   $savedSearch        = new SavedSearch();
   $json               = getJSONobj();
   $savedSearchSelects = $json->encode(array($GLOBALS['app_strings']['LBL_SAVED_SEARCH_SHORTCUT'] . '<br>' . $savedSearch->getSelect('Products')));
   $str = "<script>
   YAHOO.util.Event.addListener(window, 'load', SUGAR.util.fillShortcuts, $savedSearchSelects);
   </script>";
   echo $str;
?>
