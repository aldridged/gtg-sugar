<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/**
 * Advanced, robust set of sales and support modules.
 *
 * @package OpenSales for SugarCRM
 * @subpackage Products
 * @copyright 2008 php|webpros.com(tm)  http://www.phpwebpros.com/
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author Rustin Phares <rustin.phares@phpwebpros.com>
 */

/*******************************************************************************
 * Layout definition for Products
 *******************************************************************************/

$layout_defs['Products'] = array(
//LIST OF WHAT SUBPANELS TO SHOW IN THE DETAILVIEW 
    'subpanel_setup' => array(
//BUILDER:END of subpanels
        'activities' => array(
            'order'                     =>  20,
            'sort_order'                => 'desc',
            'sort_by'                   => 'date_start',
            'title_key'                 => 'LBL_ACTIVITIES_SUBPANEL_TITLE',
            'type'                      => 'collection',
            'subpanel_name'             => 'activities',
            'module'                    => 'Activities',

            'top_buttons' => array(
                array('widget_class'    => 'SubPanelTopCreateTaskButton'),
                array('widget_class'    => 'SubPanelTopScheduleMeetingButton'),
                array('widget_class'    => 'SubPanelTopScheduleCallButton'),
            ),

            'collection_list' => array( 
                'meetings' => array(
                    'module'            => 'Meetings',
                    'subpanel_name'     => 'ForActivities',
                    'get_subpanel_data' => 'meetings',
                ),
                'tasks' => array(
                    'module'            => 'Tasks',
                    'subpanel_name'     => 'ForActivities',
                    'get_subpanel_data' => 'tasks',
                ),
                'calls' => array(
                    'module'            => 'Calls',
                    'subpanel_name'     => 'ForActivities',
                    'get_subpanel_data' => 'calls',
                ),  
            )           
        ),
        'history' => array(
            'order'                     =>  30,
            'sort_order'                => 'desc',
            'sort_by'                   => 'date_modified',
            'title_key'                 => 'LBL_HISTORY_SUBPANEL_TITLE',
            'type'                      => 'collection',
            'subpanel_name'             => 'history',
            'module'                    => 'History',

            'top_buttons' => array(
            array('widget_class'        => 'SubPanelTopCreateNoteButton'),
            array('widget_class'        => 'SubPanelTopSummaryButton'),
            ),

            'collection_list' => array( 
                'meetings' => array(
                    'module'            => 'Meetings',
                    'subpanel_name'     => 'ForHistory',
                    'get_subpanel_data' => 'meetings',
                ),
                'tasks' => array(
                    'module'            => 'Tasks',
                    'subpanel_name'     => 'ForHistory',
                    'get_subpanel_data' => 'tasks',
                ),
                'calls' => array(
                    'module'            => 'Calls',
                    'subpanel_name'     => 'ForHistory',
                    'get_subpanel_data' => 'calls',
                ),  
                'notes' => array(
                    'module'            => 'Notes',
                    'subpanel_name'     => 'ForHistory',
                    'get_subpanel_data' => 'notes',
                ),  
            )           
        ),
		
		/*'products' => array(
			'order' => 10,
			'sort_order' => 'asc',
			'sort_by' => 'name',
			'module' => 'Products',
			'subpanel_name' => 'default',
			'get_subpanel_data' => 'product_products',
			'add_subpanel_data' => 'product_products_id',
			'title_key' => 'LBL_REL_PRODS_SUBPANEL_TITLE',
			'top_buttons' => array(
				array('widget_class' => 'SubPanelTopButtonQuickCreate'),
				array('widget_class' => 'SubPanelTopSelectButton', 'mode'=>'MultiSelect')
			),
		),*/
    ),
);
?>
